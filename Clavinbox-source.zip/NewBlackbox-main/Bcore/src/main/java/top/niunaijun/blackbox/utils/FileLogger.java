package top.niunaijun.blackbox.utils;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Process;
import android.text.format.DateFormat;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.core.env.BEnvironment;

/**
 * Writes every Slog call and every fatal crash, for the app currently hosted in this
 * process, to a single plain-text file the user can find without adb:
 *
 *   .../files/blackbox/storage/emulated/0/<App Name>.log
 *
 * One file per cloned app, named after the app's own display name (the same label
 * shown on its launcher icon), sitting directly in the shared storage root alongside
 * each app's own per-app folder. This is a diagnostic aid only: it never throws, and
 * if anything about the logging itself fails, it silently gives up rather than risk
 * crashing the very app it's trying to log for.
 */
public final class FileLogger {

    // Only ever cached once resolution SUCCEEDS (the package name is stable for the
    // rest of this process's life at that point). A failed attempt is NOT cached,
    // because engine bootstrap logs plenty of its own messages before the guest app
    // actually finishes attaching — caching a failure permanently meant the log file
    // was never created even once the app was fully running.
    private static volatile String sResolvedFileName;
    private static final Object LOCK = new Object();

    // Guards against re-entering this logger from inside its own resolution path —
    // some BlackBoxCore accessors log via Slog on failure, which would otherwise
    // call back into this class while it's still resolving, risking infinite recursion.
    private static final ThreadLocal<Boolean> sInProgress = new ThreadLocal<Boolean>() {
        @Override
        protected Boolean initialValue() {
            return false;
        }
    };

    private FileLogger() {
    }

    public static void append(String level, String tag, String msg) {
        if (Boolean.TRUE.equals(sInProgress.get())) return;
        try {
            sInProgress.set(true);
            File logFile = resolveLogFile();
            if (logFile == null) return;

            synchronized (LOCK) {
                try (PrintWriter pw = new PrintWriter(new FileWriter(logFile, true))) {
                    String time = DateFormat.format("yyyy-MM-dd HH:mm:ss.sss", System.currentTimeMillis()).toString();
                    pw.println(time + "  pid=" + Process.myPid() + "  " + level + "/" + tag + ": " + msg);
                }
            }
        } catch (Throwable ignored) {
            // Logging must never be the thing that crashes the app.
        } finally {
            sInProgress.set(false);
        }
    }

    /** Called from CrashHandler with the full stack trace, clearly marked as fatal. */
    public static void appendFatal(Thread thread, Throwable error) {
        if (Boolean.TRUE.equals(sInProgress.get())) return;
        try {
            sInProgress.set(true);
            File logFile = resolveLogFile();
            if (logFile == null) return;

            synchronized (LOCK) {
                try (PrintWriter pw = new PrintWriter(new FileWriter(logFile, true))) {
                    String time = DateFormat.format("yyyy-MM-dd HH:mm:ss.sss", System.currentTimeMillis()).toString();
                    pw.println("================================================================");
                    pw.println(time + "  FATAL EXCEPTION on thread \"" + thread.getName() + "\"  pid=" + Process.myPid());
                    error.printStackTrace(pw);
                    pw.println("================================================================");
                }
            }
        } catch (Throwable ignored) {
        } finally {
            sInProgress.set(false);
        }
    }

    private static File resolveLogFile() {
        try {
            if (sResolvedFileName == null) {
                synchronized (LOCK) {
                    if (sResolvedFileName == null) {
                        // Not cached on failure on purpose: retry every call until the
                        // guest app has actually attached and a real package name exists.
                        sResolvedFileName = resolveAppLabel();
                    }
                }
            }
            if (sResolvedFileName == null) return null;

            File dir = BEnvironment.getExternalUserDir(0);
            if (dir != null && !dir.exists()) {
                //noinspection ResultOfMethodCallIgnored
                dir.mkdirs();
            }
            return new File(dir, sResolvedFileName + ".log");
        } catch (Throwable ignored) {
            return null;
        }
    }

    /**
     * Resolves the human-readable app name the same way the engine already does for a
     * clone's task/recents label, so the log file name matches what the user actually
     * sees for that clone. Falls back to the package name, then gives up (returns
     * null) if this process isn't yet hosting a guest app at all (e.g. very early
     * engine/host-process bootstrap, before any clone has been attached).
     */
    private static String resolveAppLabel() {
        try {
            String packageName = BlackBoxCore.getAppPackageName();
            if (packageName == null || packageName.isEmpty()) return null;

            String label = packageName;
            try {
                PackageManager pm = BlackBoxCore.getPackageManager();
                if (pm != null) {
                    ApplicationInfo info = pm.getApplicationInfo(packageName, 0);
                    CharSequence loaded = pm.getApplicationLabel(info);
                    if (loaded != null && loaded.length() > 0) {
                        label = loaded.toString();
                    }
                }
            } catch (Throwable ignored) {
                // Fall back to the package name resolved above.
            }

            return sanitizeFileName(label);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static String sanitizeFileName(String name) {
        String cleaned = name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (cleaned.isEmpty()) cleaned = "app";
        return cleaned;
    }
}
